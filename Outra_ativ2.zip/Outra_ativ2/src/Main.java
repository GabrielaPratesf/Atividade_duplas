public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
public class Fracao {
    private int numerador;
    private int denominador;

    public Fracao(int numerador, int denominador) {
        this.numerador = numerador;
        this.denominador = denominador;
    }

    public Fracao multiplicar(Fracao outraFracao) {
        int novoNumerador = this.numerador * outraFracao.numerador;
        int novoDenominador = this.denominador * outraFracao.denominador;
        return new Fracao(novoNumerador, novoDenominador);
    }

    public String toString() {
        return this.numerador + "/" + this.denominador;
    }

    public static void main(String[] args) {
        Fracao fracao1 = new Fracao(2, 3);
        Fracao fracao2 = new Fracao(4, 5);
        Fracao resultado = fracao1.multiplicar(fracao2);
        System.out.println("Resultado da multiplicação: " + resultado);
    }
}

