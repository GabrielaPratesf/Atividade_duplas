public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
public class Relogio {
    private Ponteiro ponteiroHora;
    private Ponteiro ponteiroMinuto;
    private Ponteiro ponteiroSegundo;

    public Relogio() {
        this.ponteiroHora = new Ponteiro(12);
        this.ponteiroMinuto = new Ponteiro(60);
        this.ponteiroSegundo = new Ponteiro(60);
    }

    public void acertarRelogio(int hora, int minuto, int segundo) {
        this.ponteiroHora.posicao(hora);
        this.ponteiroMinuto.posicao(minuto);
        this.ponteiroSegundo.posicao(segundo);
    }

    public int lerHora() {
        return this.ponteiroHora.lerPosicao();
    }

    public int lerMinuto() {
        return this.ponteiroMinuto.lerPosicao();
    }

    public int lerSegundo() {
        return this.ponteiroSegundo.lerPosicao();
    }

    public static void main(String[] args) {
        Relogio relogio = new Relogio();
        relogio.acertarRelogio(10, 30, 45);
        System.out.println("Hora atual: " + relogio.lerHora() + ":" + relogio.lerMinuto() + ":" + relogio.lerSegundo());
    }
}

public class Ponteiro {
    private int posicao;
    private int limite;

    public Ponteiro(int limite) {
        this.limite = limite;
    }

    public void posicao(int posicao) {
        if (posicao >= 0 && posicao < this.limite) {
            this.posicao = posicao;
        }
    }

    public int lerPosicao() {
        return this.posicao;
    }
}
