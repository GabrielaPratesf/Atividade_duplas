public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
public class Triangulo {
    private double base;
    private double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public double calcularArea() {
        return (base * altura) / 2;
    }
}

public class Quadrado {
    private double lado;

    public Quadrado(double lado) {
        this.lado = lado;
    }

    public double calcularArea() {
        return lado * lado;
    }
}

public class Circunferencia {
    private double raio;
    private final double PI = 3.14159265359;

    public Circunferencia(double raio) {
        this.raio = raio;
    }

    public double calcularArea() {
        return PI * raio * raio;
    }
}

public class Trapezio {
    private double baseMaior;
    private double baseMenor;
    private double altura;

    public Trapezio(double baseMaior, double baseMenor, double altura) {
        this.baseMaior = baseMaior;
        this.baseMenor = baseMenor;
        this.altura = altura;
    }

    public double calcularArea() {
        return ((baseMaior + baseMenor) * altura) / 2;
    }
}

    Triangulo t = new Triangulo(5, 3);
    double areaTriangulo = t.calcularArea(); // resultado: 7.5

    Quadrado q = new Quadrado(4);
    double areaQuadrado = q.calcularArea(); // resultado: 16

    Circunferencia c = new Circunferencia(2);
    double areaCircunferencia = c.calcularArea(); // resultado: 12.5663706144

    Trapezio tr = new Trapezio(3, 5, 2);
    double areaTrapezio = tr.calcularArea(); // resultado: 8

